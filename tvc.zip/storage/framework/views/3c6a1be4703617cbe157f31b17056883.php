

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4">
        <h2 class="text-2xl mb-4 text-center">Ejemplo de Card</h2>
        
        <!-- Aquí incluimos la card como subvista -->
        <?php echo $__env->make('cards.instructor_card-v4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\tvc\resources\views/personal/example-v4.blade.php ENDPATH**/ ?>