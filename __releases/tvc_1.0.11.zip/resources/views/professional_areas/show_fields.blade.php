<!-- Professional Id Field -->
<div class="col-sm-12">
    {!! Form::label('professional_id', 'Professional Id:') !!}
    <p>{{ $professionalArea->professional_id }}</p>
</div>

<!-- Area Id Field -->
<div class="col-sm-12">
    {!! Form::label('area_id', 'Area Id:') !!}
    <p>{{ $professionalArea->area_id }}</p>
</div>

