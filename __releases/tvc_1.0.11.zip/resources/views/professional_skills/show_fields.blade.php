<!-- Professional Id Field -->
<div class="col-sm-12">
    {!! Form::label('professional_id', 'Professional Id:') !!}
    <p>{{ $professionalSkill->professional_id }}</p>
</div>

<!-- Skill Id Field -->
<div class="col-sm-12">
    {!! Form::label('skill_id', 'Skill Id:') !!}
    <p>{{ $professionalSkill->skill_id }}</p>
</div>

<!-- Expertise Level Field -->
<div class="col-sm-12">
    {!! Form::label('expertise_level', 'Expertise Level:') !!}
    <p>{{ $professionalSkill->expertise_level }}</p>
</div>

