<!-- Professional Id Field -->
<div class="col-sm-12">
    {!! Form::label('professional_id', 'Professional Id:') !!}
    <p>{{ $professionalLineFamily->professional_id }}</p>
</div>

<!-- Line Family Id Field -->
<div class="col-sm-12">
    {!! Form::label('line_family_id', 'Line Family Id:') !!}
    <p>{{ $professionalLineFamily->line_family_id }}</p>
</div>

<!-- Expertise Level Field -->
<div class="col-sm-12">
    {!! Form::label('expertise_level', 'Expertise Level:') !!}
    <p>{{ $professionalLineFamily->expertise_level }}</p>
</div>

