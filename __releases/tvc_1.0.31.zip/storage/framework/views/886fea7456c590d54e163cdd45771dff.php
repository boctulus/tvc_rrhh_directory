<!-- need to remove -->
<li class="nav-item">
    <a href="<?php echo e(route('home')); ?>" class="nav-link <?php echo e(Request::is('home') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Home</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('brands.index')); ?>" class="nav-link <?php echo e(Request::is('brands*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Brands</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('areas.index')); ?>" class="nav-link <?php echo e(Request::is('areas*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Areas</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('certifications.index')); ?>" class="nav-link <?php echo e(Request::is('certifications*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Certifications</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('lines-families.index')); ?>" class="nav-link <?php echo e(Request::is('linesFamilies*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Lines Families</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('positions.index')); ?>" class="nav-link <?php echo e(Request::is('positions*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Positions</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('professionals.index')); ?>" class="nav-link <?php echo e(Request::is('professionals*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Professionals</p>
    </a>
</li>

<!-- <li class="nav-item">
    <a href="<?php echo e(route('professional-areas.index')); ?>" class="nav-link <?php echo e(Request::is('professionalAreas*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Professional Areas</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('professional-brands.index')); ?>" class="nav-link <?php echo e(Request::is('professionalBrands*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Professional Brands</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('professional-certifications.index')); ?>" class="nav-link <?php echo e(Request::is('professionalCertifications*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Professional Certifications</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('professional-line-families.index')); ?>" class="nav-link <?php echo e(Request::is('professionalLineFamilies*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Professional Line Families</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('professional-skills.index')); ?>" class="nav-link <?php echo e(Request::is('professionalSkills*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>Professional Skills</p>
    </a>
</li> -->

<li class="nav-item">
    <a href="<?php echo e(route('states.index')); ?>" class="nav-link <?php echo e(Request::is('states*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-home"></i>
        <p>States</p>
    </a>
</li>

<li class="nav-header">NAVEGACIÓN</li>
<li class="nav-item">
    <a href="<?php echo e(route('personal.index')); ?>" class="nav-link <?php echo e(Request::is('personal*') ? 'active' : ''); ?>">
        <i class="nav-icon fas fa-th-large"></i>
        <p>Ir al Grid</p>
    </a>
</li>
<?php /**PATH D:\laragon\www\tvc\resources\views/layouts/menu.blade.php ENDPATH**/ ?>