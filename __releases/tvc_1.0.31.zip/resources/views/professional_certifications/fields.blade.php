<!-- Professional Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('professional_id', 'Professional Id:') !!}
    {!! Form::number('professional_id', null, ['class' => 'form-control', 'required']) !!}
</div>

<!-- Certification Id Field -->
<div class="form-group col-sm-6">
    {!! Form::label('certification_id', 'Certification Id:') !!}
    {!! Form::number('certification_id', null, ['class' => 'form-control', 'required']) !!}
</div>