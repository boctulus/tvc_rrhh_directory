<!-- Professional Id Field -->
<div class="col-sm-12">
    {!! Form::label('professional_id', 'Professional Id:') !!}
    <p>{{ $professionalCertification->professional_id }}</p>
</div>

<!-- Certification Id Field -->
<div class="col-sm-12">
    {!! Form::label('certification_id', 'Certification Id:') !!}
    <p>{{ $professionalCertification->certification_id }}</p>
</div>

