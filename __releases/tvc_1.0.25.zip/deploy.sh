#!/bin/bash
# Compile assets for production
npm run production

# Optional: Remove source maps and dev files
find public/build -name "*.map" -delete