<div class="row">
    <?php echo $records->links(); ?>

</div>
<?php /**PATH D:\laragon\www\tvc\resources\views/vendor/adminlte-templates/common/paginate.blade.php ENDPATH**/ ?>