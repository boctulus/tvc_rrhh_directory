<!-- Name Field -->
<div class="col-sm-12">
    <?php echo Form::label('name', 'Name:'); ?>

    <p><?php echo e($professional->name); ?></p>
</div>

<!-- Position Field -->
<div class="col-sm-12">
    <?php echo Form::label('position_id', 'Position:'); ?>

    <p><?php echo e($professional->position->name); ?></p>
</div>

<!-- Contact Field -->
<div class="col-sm-12">
    <?php echo Form::label('contact', 'Contact:'); ?>

    <p><?php echo e($professional->contact); ?></p>
</div>

<!-- Email Field -->
<div class="col-sm-12">
    <?php echo Form::label('email', 'Email:'); ?>

    <p><?php echo e($professional->email); ?></p>
</div>

<!-- Phone Field -->
<div class="col-sm-12">
    <?php echo Form::label('phone', 'Phone:'); ?>

    <p><?php echo e($professional->phone); ?></p>
</div>

<!-- Phone2 Field -->
<div class="col-sm-12">
    <?php echo Form::label('phone2', 'Phone2:'); ?>

    <p><?php echo e($professional->phone2); ?></p>
</div>

<!-- Img Url Field -->
<div class="col-sm-12">
    <?php echo Form::label('img_url', 'Img Url:'); ?>

    <p><?php echo e($professional->img_url); ?></p>
</div>

<div class="form-group col-sm-6">
    <?php echo Form::label('areas', 'Areas:'); ?>

    <?php echo Form::select('areas[]', 
        \App\Models\Area::pluck('name', 'id'), 
        isset($professional) ? $professional->areas->pluck('id')->toArray() : [], 
        [
            'class' => 'form-control select2', 
            'multiple' => 'multiple',
            'placeholder' => 'Select Areas'
        ]
    ); ?>

</div>

<script>
$(document).ready(function() {
    $('.select2').select2({
        placeholder: 'Select Areas',
        allowClear: true
    });
});
</script>

<!-- Expertise Field -->
<div class="col-sm-12">
    <?php echo Form::label('expertise', 'Expertise Level:'); ?>

    <p>
        <?php switch($professional->expertise):
            case (1): ?>
                1 - Basic ★
                <?php break; ?>
            <?php case (2): ?>
                2 - Intermediate ★★
                <?php break; ?>
            <?php case (3): ?>
                3 - Proficient ★★★
                <?php break; ?>
            <?php case (4): ?>
                4 - Advanced ★★★★
                <?php break; ?>
            <?php case (5): ?>
                5 - Expert ★★★★★
                <?php break; ?>
            <?php default: ?>
                Not Specified
        <?php endswitch; ?>
    </p>
</div>

<!-- Location Field -->
<div class="col-sm-12">
    <?php echo Form::label('location_id', 'Location:'); ?>

    <p><?php echo e($professional->location->name); ?></p>
</div>

<!-- Line Families Field -->
<div class="col-sm-12">
    <?php echo Form::label('lines_families', 'Line Families:'); ?>

    <div>
        <?php if($professional->professionalLineFamilies->count() > 0): ?>
            <?php $__currentLoopData = $professional->professionalLineFamilies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mb-1">
                    <?php echo e($plf->lineFamily->name); ?> - 
                    <?php switch($plf->expertise_level):
                        case (1): ?>
                            Basic ★
                            <?php break; ?>
                        <?php case (2): ?>
                            Intermediate ★★
                            <?php break; ?>
                        <?php case (3): ?>
                            Proficient ★★★
                            <?php break; ?>
                        <?php case (4): ?>
                            Advanced ★★★★
                            <?php break; ?>
                        <?php case (5): ?>
                            Expert ★★★★★
                            <?php break; ?>
                    <?php endswitch; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            No Line Families
        <?php endif; ?>
    </div>
</div>

<!-- Certifications Field -->
<div class="col-sm-12">
    <?php echo Form::label('certifications', 'Certifications:'); ?>

    <p>
        <?php if($professional->professionalCertifications->count() > 0): ?>
            <?php echo e($professional->professionalCertifications->pluck('certification.name')->implode(', ')); ?>

        <?php else: ?>
            No Certifications
        <?php endif; ?>
    </p>
</div>
<?php /**PATH D:\laragon\www\tvc\resources\views/professionals/show_fields.blade.php ENDPATH**/ ?>