<!-- Professional Id Field -->
<div class="col-sm-12">
    {!! Form::label('professional_id', 'Professional Id:') !!}
    <p>{{ $professionalBrand->professional_id }}</p>
</div>

<!-- Brand Id Field -->
<div class="col-sm-12">
    {!! Form::label('brand_id', 'Brand Id:') !!}
    <p>{{ $professionalBrand->brand_id }}</p>
</div>

