<!-- Name Field -->
<div class="col-sm-12">
    {!! Form::label('name', 'Name:') !!}
    <p>{{ $state->name }}</p>
</div>

<!-- Abbreviation Field -->
<div class="col-sm-12">
    {!! Form::label('abbreviation', 'Abbreviation:') !!}
    <p>{{ $state->abbreviation }}</p>
</div>

